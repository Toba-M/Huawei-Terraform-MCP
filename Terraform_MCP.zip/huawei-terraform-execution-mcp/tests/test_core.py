import hashlib
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import core


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.p = self.root / 'demo'
        self.p.mkdir()
        (self.p / 'main.tf').write_text('terraform {}', encoding='utf-8')
        self.envpatch = patch.dict(os.environ, {'TF_MCP_ROOT': str(self.root), 'TF_MCP_ALLOW_APPLY': '0'}, clear=False)
        self.envpatch.start()

    def tearDown(self):
        self.envpatch.stop()
        self.tmp.cleanup()

    def test_names_are_restricted(self):
        for bad in ('../secret', '..', 'demo/../x', '', 'C:'):
            with self.assertRaises(ValueError):
                core.get_project(bad)
        self.assertEqual(core.list_projects(), ['demo'])

    def test_plan_path_is_bounded(self):
        self.assertEqual(core.plan_path('demo', 'tfplan').parent, self.p)
        for bad in ('../file', '..', 'foo/bar'):
            with self.assertRaises(ValueError):
                core.plan_path('demo', bad)

    def test_apply_default_disabled(self):
        (self.p / 'tfplan').write_bytes(b'plan')
        digest = hashlib.sha256(b'plan').hexdigest()
        with self.assertRaises(PermissionError):
            core.apply_saved_plan('demo', 'tfplan', digest)

    def test_apply_requires_independent_digest(self):
        (self.p / 'tfplan').write_bytes(b'plan')
        digest = hashlib.sha256(b'plan').hexdigest()
        os.environ['TF_MCP_ALLOW_APPLY'] = '1'
        with self.assertRaises(PermissionError):
            core.apply_saved_plan('demo', 'tfplan', digest)
        os.environ['TF_MCP_APPROVED_PLAN_SHA256'] = '0' * 64
        with self.assertRaises(PermissionError):
            core.apply_saved_plan('demo', 'tfplan', digest)

    def test_approved_plan_command_uses_exact_file_no_shell(self):
        (self.p / 'tfplan').write_bytes(b'plan')
        digest = hashlib.sha256(b'plan').hexdigest()
        os.environ['TF_MCP_ALLOW_APPLY'] = '1'
        os.environ['TF_MCP_APPROVED_PLAN_SHA256'] = digest
        with patch('core._run', return_value={'ok': True}) as p:
            core.apply_saved_plan('demo', 'tfplan', digest)
            p.assert_called_once_with('demo', ['apply', '-input=false', '-no-color', 'tfplan'], 1800)


if __name__ == '__main__':
    unittest.main()
