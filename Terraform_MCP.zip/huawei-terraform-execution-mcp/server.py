"""Huawei Terraform MCP stdio server (reconstructed, not original ZIP source)."""
from mcp.server.fastmcp import FastMCP
from core import (
    apply_saved_plan, fmt, init, list_projects, plan, plan_digest,
    show_plan, validate, version,
)

mcp = FastMCP("huawei-terraform")


@mcp.tool()
def terraform_projects() -> list[str]:
    """List Terraform project names under the configured TF_MCP_ROOT."""
    return list_projects()


@mcp.tool()
def terraform_version() -> dict:
    """Return installed Terraform CLI version without changing cloud resources."""
    return version()


@mcp.tool()
def terraform_init(project: str) -> dict:
    """Initialize providers and backend for an existing allowlisted project."""
    return init(project)


@mcp.tool()
def terraform_fmt(project: str) -> dict:
    """Check Terraform formatting without modifying project files."""
    return fmt(project)


@mcp.tool()
def terraform_validate(project: str) -> dict:
    """Validate configuration syntax and provider schema; no cloud mutation."""
    return validate(project)


@mcp.tool()
def terraform_plan(project: str, plan_name: str = "tfplan") -> dict:
    """Create a saved Terraform plan file, no apply. The file may be sensitive."""
    return plan(project, plan_name)


@mcp.tool()
def terraform_show_plan(project: str, plan_name: str = "tfplan") -> dict:
    """Display reviewable saved plan; output may include infrastructure metadata."""
    return show_plan(project, plan_name)


@mcp.tool()
def terraform_plan_digest(project: str, plan_name: str = "tfplan") -> dict:
    """Show SHA256 digest and size of saved plan for independent approval."""
    return plan_digest(project, plan_name)


@mcp.tool()
def terraform_apply_saved_plan(project: str, plan_name: str, approval_sha256: str) -> dict:
    """Apply EXACT saved plan only when apply gate AND independent digest gate are set."""
    return apply_saved_plan(project, plan_name, approval_sha256)


if __name__ == "__main__":
    mcp.run(transport="stdio")
