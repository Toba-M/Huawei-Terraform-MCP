"""Print CodeArts mcpServers configuration for this installed package.

Run using outer .venv's Python from any working directory; no secrets printed.
"""
import json
import os
import sys
from pathlib import Path

package = Path(__file__).resolve().parents[1]
root = package / "projects"
region = os.environ.get("HW_REGION_NAME", "af-south-1")
config = {
    "mcpServers": {
        "huawei-terraform": {
            "disabled": False,
            "timeout": 60,
            "type": "stdio",
            "command": sys.executable.replace("\\", "/"),
            "args": [str(package / "server.py").replace("\\", "/")],
            "env": {
                "TF_MCP_ROOT": str(root).replace("\\", "/"),
                "TF_MCP_ALLOW_APPLY": "0",
                "HW_REGION_NAME": region,
            },
        }
    }
}
print(json.dumps(config, ensure_ascii=False, indent=2))
