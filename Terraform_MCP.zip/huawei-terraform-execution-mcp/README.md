# Huawei Terraform execution MCP — reconstructed training package

This is a **newly reconstructed** local Python/MCP implementation based on the
October 2026 CodeArts workflow, **not a recovered byte-for-byte original ZIP**.
Do not deploy to production without review and successful staging tests.

## Setup (Windows PowerShell)

1. Download the ZIP from the same ChatGPT reply as the Word guide.
2. Expand to `C:\CodeArts\huawei-terraform-execution-mcp` (resulting inner
   directory `C:\CodeArts\huawei-terraform-execution-mcp\huawei-terraform-execution-mcp`).
3. Install Python 3.11 and Terraform; confirm `py -3.11 --version` and `terraform version`.
4. In PowerShell:

```powershell
Set-Location 'C:\CodeArts\huawei-terraform-execution-mcp'
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r .\huawei-terraform-execution-mcp\requirements.txt
.\.venv\Scripts\python.exe -m unittest discover -s .\huawei-terraform-execution-mcp\tests -v
.\.venv\Scripts\python.exe .\huawei-terraform-execution-mcp\scripts\print_codearts_config.py
```

5. Copy the printed `huawei-terraform` entry into CodeArts project `.codeartsdoer/mcp/mcp_settings.json` under `mcpServers`. Your real `HW_ACCESS_KEY`, `HW_SECRET_KEY`, `HW_REGION_NAME=af-south-1` must be inherited from Windows user environment; restart CodeArts after editing.
6. The provided Terraform demo needs real AZ/flavor/image/key pair values in a copied `terraform.auto.tfvars`; never put secrets in it.
7. In CodeArts, discover MCP tools; call `terraform_version`, then `terraform_init`, `terraform_fmt`, `terraform_validate`, `terraform_plan`, `terraform_show_plan`.

## Safety

- `TF_MCP_ALLOW_APPLY=0` by default.
- Even when explicitly set to `1`, saved-plan apply also requires a separate `TF_MCP_APPROVED_PLAN_SHA256` in the MCP process environment that matches both the file digest and the tool argument. Both env gates are manually operated. Restart CodeArts to inherit updated variables.
- Credentials, binary plans, outputs and Terraform state can be sensitive. Do not paste them into prompts or commit them to source control.
- This package does **not** implement `terraform destroy` or arbitrary shell command execution.
- Testing validates code paths locally; it is not proof of cloud provisioning.

Provider reference: https://github.com/huaweicloud/terraform-provider-huaweicloud/blob/master/examples/ecs/basic/main.tf
SDK reference: https://py.sdk.modelcontextprotocol.io/v1/
