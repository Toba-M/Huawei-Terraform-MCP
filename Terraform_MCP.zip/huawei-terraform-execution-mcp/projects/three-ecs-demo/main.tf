resource "huaweicloud_vpc" "demo" {
  name = "codearts-three-ecs-vpc"
  cidr = "10.60.0.0/16"
}

resource "huaweicloud_vpc_subnet" "demo" {
  name       = "codearts-three-ecs-subnet"
  vpc_id     = huaweicloud_vpc.demo.id
  cidr       = "10.60.1.0/24"
  gateway_ip = "10.60.1.1"
}

resource "huaweicloud_networking_secgroup" "demo" {
  name                 = "codearts-three-ecs-sg"
  delete_default_rules = true
}

# No inbound access. Allow outbound for OS package operations; adjust to policy.
resource "huaweicloud_networking_secgroup_rule" "egress" {
  security_group_id = huaweicloud_networking_secgroup.demo.id
  direction         = "egress"
  ethertype         = "IPv4"
  remote_ip_prefix  = "0.0.0.0/0"
  priority          = 1
}

resource "huaweicloud_compute_instance" "demo" {
  count              = 3
  name               = format("codearts-ecs-%02d", count.index + 1)
  availability_zone  = var.availability_zone
  flavor_id          = var.flavor_id
  image_id           = var.image_id
  key_pair           = var.key_pair
  security_group_ids = [huaweicloud_networking_secgroup.demo.id]
  network {
    uuid = huaweicloud_vpc_subnet.demo.id
  }
}
