output "vpc_id" {
  value = huaweicloud_vpc.demo.id
}
output "subnet_id" {
  value = huaweicloud_vpc_subnet.demo.id
}
output "ecs_ids" {
  value = huaweicloud_compute_instance.demo[*].id
}
