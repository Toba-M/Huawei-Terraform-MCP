variable "availability_zone" {
  description = "Existing AZ in af-south-1; confirm in console."
  type        = string
}
variable "flavor_id" {
  description = "ECS flavor ID available in selected AZ."
  type        = string
}
variable "image_id" {
  description = "Ubuntu public/private image ID available in region."
  type        = string
}
variable "key_pair" {
  description = "Existing ECS SSH key pair name in this region."
  type        = string
}
