"""Bounded Terraform command runner for a local MCP server.

Security model: project-name-only traversal into an allowlisted root, no shell,
non-interactive commands, apply disabled unless two independent environment gates
and the caller-supplied saved-plan SHA256 all match.
"""
from __future__ import annotations

import hashlib
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

PROJECT_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$")
PLAN_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")
SHA256_RE = re.compile(r"^[a-f0-9]{64}$")
MAX_OUTPUT = 24000


def project_root() -> Path:
    configured = os.environ.get("TF_MCP_ROOT", "").strip()
    base = Path(configured) if configured else Path(__file__).resolve().parent / "projects"
    return base.expanduser().resolve()


def list_projects() -> list[str]:
    root = project_root()
    if not root.is_dir():
        return []
    return sorted(
        p.name for p in root.iterdir()
        if p.is_dir() and PROJECT_RE.fullmatch(p.name)
        and p.resolve().parent == root
        and any(p.glob("*.tf"))
    )


def get_project(project: str) -> Path:
    if not PROJECT_RE.fullmatch(project):
        raise ValueError("Invalid project name. Use only letters, numbers, '-' and '_'.")
    root = project_root()
    target = (root / project).resolve()
    if target.parent != root or not target.is_dir():
        raise ValueError("Unknown or disallowed Terraform project directory.")
    if not any(target.glob("*.tf")):
        raise ValueError("Project has no Terraform .tf files.")
    return target


def plan_path(project: str, plan_name: str = "tfplan") -> Path:
    if not PLAN_RE.fullmatch(plan_name) or plan_name in {".", ".."}:
        raise ValueError("Invalid plan filename.")
    base = get_project(project)
    dest = (base / plan_name).resolve()
    if dest.parent != base:
        raise ValueError("Plan path must be a file directly inside the project.")
    return dest


def _run(project: str | None, args: list[str], timeout: int = 300) -> dict[str, Any]:
    terraform = shutil.which("terraform")
    if terraform is None:
        raise RuntimeError("Terraform is not available on PATH inherited by the MCP server.")
    cwd = get_project(project) if project else project_root()
    cwd.mkdir(parents=True, exist_ok=True) if project is None else None
    env = dict(os.environ)
    env["TF_IN_AUTOMATION"] = "1"
    env["TF_INPUT"] = "0"
    try:
        proc = subprocess.run(
            [terraform, *args], cwd=str(cwd), env=env,
            shell=False, capture_output=True, text=True,
            encoding="utf-8", errors="replace", timeout=timeout,
        )
        raw = (proc.stdout or "") + ("\n" + proc.stderr if proc.stderr else "")
        return {"ok": proc.returncode == 0, "exit_code": proc.returncode,
                "args": ["terraform", *args], "project": project,
                "output": raw[:MAX_OUTPUT], "truncated": len(raw) > MAX_OUTPUT}
    except subprocess.TimeoutExpired as exc:
        return {"ok": False, "exit_code": None, "args": ["terraform", *args],
                "project": project, "output": f"Terraform timeout after {timeout}s: {exc}", "truncated": False}


def version() -> dict[str, Any]:
    return _run(None, ["version"], 25)


def init(project: str) -> dict[str, Any]:
    return _run(project, ["init", "-input=false", "-no-color"], 600)


def fmt(project: str) -> dict[str, Any]:
    # Deliberately check-only: no file edits through this tool.
    return _run(project, ["fmt", "-check", "-diff", "-no-color"], 90)


def validate(project: str) -> dict[str, Any]:
    return _run(project, ["validate", "-no-color"], 180)


def plan(project: str, plan_name: str = "tfplan") -> dict[str, Any]:
    dest = plan_path(project, plan_name)
    if dest.exists() and dest.is_symlink():
        raise ValueError("Refusing to overwrite a symbolic-link plan.")
    r = _run(project, ["plan", "-input=false", "-no-color", f"-out={dest.name}"], 900)
    if r["ok"] and dest.is_file():
        r["plan_file"] = str(dest)
        r["sha256"] = hashlib.sha256(dest.read_bytes()).hexdigest()
    return r


def plan_digest(project: str, plan_name: str = "tfplan") -> dict[str, Any]:
    dest = plan_path(project, plan_name)
    if not dest.is_file():
        raise FileNotFoundError("Saved plan not found; run terraform_plan first.")
    return {"project": project, "plan_file": str(dest),
            "sha256": hashlib.sha256(dest.read_bytes()).hexdigest(),
            "size_bytes": dest.stat().st_size}


def show_plan(project: str, plan_name: str = "tfplan") -> dict[str, Any]:
    dest = plan_path(project, plan_name)
    if not dest.is_file():
        raise FileNotFoundError("Saved plan not found.")
    return _run(project, ["show", "-no-color", dest.name], 180)


def apply_saved_plan(project: str, plan_name: str, approval_sha256: str) -> dict[str, Any]:
    if os.environ.get("TF_MCP_ALLOW_APPLY", "0") != "1":
        raise PermissionError("Apply disabled at MCP server: TF_MCP_ALLOW_APPLY is not '1'.")
    if not SHA256_RE.fullmatch(approval_sha256):
        raise PermissionError("Caller must provide a lower-case 64-character plan SHA256.")
    dest = plan_path(project, plan_name)
    if not dest.is_file():
        raise FileNotFoundError("Approved plan file does not exist.")
    actual = hashlib.sha256(dest.read_bytes()).hexdigest()
    independently_approved = os.environ.get("TF_MCP_APPROVED_PLAN_SHA256", "").strip()
    if actual != approval_sha256 or actual != independently_approved:
        raise PermissionError("Saved plan digest mismatch or independent approval not set.")
    return _run(project, ["apply", "-input=false", "-no-color", dest.name], 1800)
